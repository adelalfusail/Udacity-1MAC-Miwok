package hari.allagisample;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class SampleFragment extends Fragment{
    /** Handles playback of all the sound files */
    private MediaPlayer mMediaPlayer;

    /** Handles audio focus when playing a sound file */
    private AudioManager mAudioManager;

    /**
     * This listener gets triggered whenever the audio focus changes
     * (i.e., we gain or lose audio focus because of another app or device).
     */

    private AudioManager.OnAudioFocusChangeListener mOnAudioFocusChangeListener = new AudioManager.OnAudioFocusChangeListener() {
        @Override
        public void onAudioFocusChange(int focusChange) {
            if (focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT ||
                    focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
                // The AUDIOFOCUS_LOSS_TRANSIENT case means that we've lost audio focus for a
                // short amount of time. The AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK case means that
                // our app is allowed to continue playing sound but at a lower volume. We'll treat
                // both cases the same way because our app is playing short sound files.

                // Pause playback and reset player to the start of the file. That way, we can
                // play the word from the beginning when we resume playback.
                mMediaPlayer.pause();
                mMediaPlayer.seekTo(0);
            } else if (focusChange == AudioManager.AUDIOFOCUS_GAIN) {
                // The AUDIOFOCUS_GAIN case means we have regained focus and can resume playback.
                mMediaPlayer.start();
            } else if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
                // The AUDIOFOCUS_LOSS case means we've lost audio focus and
                // Stop playback and clean up resources
                releaseMediaPlayer();
            }
        }
    };

    /**
     * This listener gets triggered when the {@link MediaPlayer} has completed
     * playing the audio file.
     */
    private MediaPlayer.OnCompletionListener mCompletionListener = new MediaPlayer.OnCompletionListener() {
        @Override
        public void onCompletion(MediaPlayer mediaPlayer) {
            // Now that the sound file has finished playing, release the media player resources.
            releaseMediaPlayer();
        }
    };


    Context context;
    TextView titleView;
    TextView rules;
    ImageButton start;
    String title = "Fragment";
    ArrayList<String> wordsList = new ArrayList<String>();
    ListView listView;

    public SampleFragment() {
        super();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_sample, container, false);

        if (getArguments() != null) {
            title = getArguments().getString("title");
        }
      //  titleView = view.findViewById(R.id.fragmentTitle);
        //titleView.setText(title);
        // Create and setup the {@link AudioManager} to request audio focus
        mAudioManager = (AudioManager) getContext().getSystemService(getActivity().AUDIO_SERVICE);
        if(title.equals("NUMBERS")) {



            // Create a list of words
            final ArrayList<Word> words = new ArrayList<Word>();
            words.add(new Word("one", "واحد", R.drawable.number_one, R.raw.one));
            words.add(new Word("two", "اثنان", R.drawable.number_two, R.raw.two));
            words.add(new Word("three", "ثلاثة", R.drawable.number_three, R.raw.three));
            words.add(new Word("four", "اربعة", R.drawable.number_four, R.raw.four));
            words.add(new Word("five", "خمسة", R.drawable.number_five, R.raw.five));
            words.add(new Word("six", "ستة", R.drawable.number_six, R.raw.six));
            words.add(new Word("seven", "سبعة", R.drawable.number_seven, R.raw.seven));
            words.add(new Word("eight", "ثمانية", R.drawable.number_eight, R.raw.eight));
            words.add(new Word("nine", "تسعة", R.drawable.number_nine, R.raw.nine));
            words.add(new Word("ten", "عشرة", R.drawable.number_ten, R.raw.ten));

            // Create an {@link WordAdapter}, whose data source is a list of {@link Word}s. The
            // adapter knows how to create list items for each item in the list.
            WordAdapter adapter = new WordAdapter(getActivity(), words, R.color.category_numbers);

            // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
            // There should be a {@link ListView} with the view ID called list, which is declared in the
            // word_list.xml layout file.
            ListView listView = view.findViewById(R.id.list);

            // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
            // {@link ListView} will display list items for each {@link Word} in the list.
            listView.setAdapter(adapter);

            // Set a click listener to play the audio when the list item is clicked on
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                    // Release the media player if it currently exists because we are about to
                    // play a different sound file
                    releaseMediaPlayer();

                    // Get the {@link Word} object at the given position the user clicked on
                    Word word = words.get(position);

                    // Request audio focus so in order to play the audio file. The app needs to play a
                    // short audio file, so we will request audio focus with a short amount of time
                    // with AUDIOFOCUS_GAIN_TRANSIENT.
                    int result = mAudioManager.requestAudioFocus(mOnAudioFocusChangeListener,
                            AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);

                    if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                        // We have audio focus now.

                        // Create and setup the {@link MediaPlayer} for the audio resource associated
                        // with the current word
                        mMediaPlayer = MediaPlayer.create(getActivity(), word.getAudioResourceId());

                        // Start the audio file
                        mMediaPlayer.start();

                        // Setup a listener on the media player, so that we can stop and release the
                        // media player once the sound has finished playing.
                        mMediaPlayer.setOnCompletionListener(mCompletionListener);
                    }
                }
            });
        }
        if(title.equals("COLORS")){

            final ArrayList<Word> words = new ArrayList<Word>();
            words.add(new Word("red", "أحمر", R.drawable.color_red, R.raw.red));
            words.add(new Word("mustard yellow", "أصفر فاتح", R.drawable.color_mustard_yellow,
                    R.raw.yellow));
            words.add(new Word("dusty yellow", "أصفر مغبر", R.drawable.color_dusty_yellow,
                    R.raw.dustyellow));
            words.add(new Word("green", "أخضر", R.drawable.color_green, R.raw.green));
            words.add(new Word("brown", "بني", R.drawable.color_brown, R.raw.brown));
            words.add(new Word("gray", "رمادي", R.drawable.color_gray, R.raw.gray));
            words.add(new Word("black", "أسود", R.drawable.color_black, R.raw.black));
            words.add(new Word("white", "أبيض", R.drawable.color_white, R.raw.white));

            // Create an {@link WordAdapter}, whose data source is a list of {@link Word}s. The
            // adapter knows how to create list items for each item in the list.
            WordAdapter adapter = new WordAdapter(getActivity(), words, R.color.category_colors);

            // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
            // There should be a {@link ListView} with the view ID called list, which is declared in the
            // word_list.xml layout file.
            ListView listView = (ListView) view.findViewById(R.id.list);

            // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
            // {@link ListView} will display list items for each {@link Word} in the list.
            listView.setAdapter(adapter);

            // Set a click listener to play the audio when the list item is clicked on
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                    // Release the media player if it currently exists because we are about to
                    // play a different sound file
                    releaseMediaPlayer();

                    // Get the {@link Word} object at the given position the user clicked on
                    Word word = words.get(position);

                    // Request audio focus so in order to play the audio file. The app needs to play a
                    // short audio file, so we will request audio focus with a short amount of time
                    // with AUDIOFOCUS_GAIN_TRANSIENT.
                    int result = mAudioManager.requestAudioFocus(mOnAudioFocusChangeListener,
                            AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);

                    if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                        // We have audio focus now.

                        // Create and setup the {@link MediaPlayer} for the audio resource associated
                        // with the current word
                        mMediaPlayer = MediaPlayer.create(getActivity(), word.getAudioResourceId());

                        // Start the audio file
                        mMediaPlayer.start();

                        // Setup a listener on the media player, so that we can stop and release the
                        // media player once the sound has finished playing.
                        mMediaPlayer.setOnCompletionListener(mCompletionListener);
                    }
                }
            });


        }
        if(title.equals("FAMILY")){

            final ArrayList<Word> words = new ArrayList<Word>();
            words.add(new Word("father", "أب", R.drawable.family_father, R.raw.father));
            words.add(new Word("mother", "أم", R.drawable.family_mother, R.raw.mother));
            words.add(new Word("son", "أبن", R.drawable.family_son, R.raw.bro));
            words.add(new Word("daughter", "ابنة", R.drawable.family_daughter, R.raw.sis));
            words.add(new Word("older brother", "ألاخ ألاكبر", R.drawable.family_older_brother,
                    R.raw.obro));
            words.add(new Word("younger brother", "ألاخ الاصغر", R.drawable.family_younger_brother,
                    R.raw.ybro));
            words.add(new Word("older sister", "ألاخت ألاكبر", R.drawable.family_older_sister,
                    R.raw.osis));
            words.add(new Word("younger sister", "ألاخت ألاصغر", R.drawable.family_younger_sister,
                    R.raw.ysis));
            words.add(new Word("grandmother ", "جدة", R.drawable.family_grandmother,
                    R.raw.gmom));
            words.add(new Word("grandfather", "جد", R.drawable.family_grandfather,
                    R.raw.gfather));

            // Create an {@link WordAdapter}, whose data source is a list of {@link Word}s. The
            // adapter knows how to create list items for each item in the list.
            WordAdapter adapter = new WordAdapter(getActivity(), words, R.color.category_family);

            // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
            // There should be a {@link ListView} with the view ID called list, which is declared in the
            // word_list.xml layout file.
            ListView listView = (ListView) view.findViewById(R.id.list);

            // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
            // {@link ListView} will display list items for each {@link Word} in the list.
            listView.setAdapter(adapter);

            // Set a click listener to play the audio when the list item is clicked on
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                    // Release the media player if it currently exists because we are about to
                    // play a different sound file
                    releaseMediaPlayer();

                    // Get the {@link Word} object at the given position the user clicked on
                    Word word = words.get(position);

                    // Request audio focus so in order to play the audio file. The app needs to play a
                    // short audio file, so we will request audio focus with a short amount of time
                    // with AUDIOFOCUS_GAIN_TRANSIENT.
                    int result = mAudioManager.requestAudioFocus(mOnAudioFocusChangeListener,
                            AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);

                    if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                        // We have audio focus now.

                        // Create and setup the {@link MediaPlayer} for the audio resource associated
                        // with the current word
                        mMediaPlayer = MediaPlayer.create(getActivity(), word.getAudioResourceId());

                        // Start the audio file
                        mMediaPlayer.start();

                        // Setup a listener on the media player, so that we can stop and release the
                        // media player once the sound has finished playing.
                        mMediaPlayer.setOnCompletionListener(mCompletionListener);
                    }
                }
            });

        }
        if(title.equals("PHRASES")){


            // Create a list of words
            final ArrayList<Word> words = new ArrayList<Word>();
            words.add(new Word("Where are you going?", "ماذا تفعل؟",
                    R.raw.whatdoing));
            words.add(new Word("What is your name?", "ماهو أسمك؟",
                    R.raw.name));
            words.add(new Word("My name is...", "أسمي هو...", R.raw.myname));
            words.add(new Word("How are you feeling?", "كيف تشعر؟", R.raw.feel));
            words.add(new Word("I'm feeling good.", "أنا جيد", R.raw.imgood));
            words.add(new Word("Are you coming?", "هل ستأتي؟", R.raw.arecoming));
            words.add(new Word("Yes, I'm coming.", "نعم سأتي", R.raw.waitimcoming));
            words.add(new Word("I'm coming.", "انا أتي", R.raw.waitimcoming));
            words.add(new Word("Let's go.", "هيا لنذهب", R.raw.ltsgo));
            words.add(new Word("Come here","تعال ألى هنا", R.raw.comehere));

            // Create an {@link WordAdapter}, whose data source is a list of {@link Word}s. The
            // adapter knows how to create list items for each item in the list.
            WordAdapter adapter = new WordAdapter(getActivity(), words, R.color.category_phrases);

            // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
            // There should be a {@link ListView} with the view ID called list, which is declared in the
            // word_list.xml layout file.
            ListView listView = (ListView) view.findViewById(R.id.list);

            // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
            // {@link ListView} will display list items for each {@link Word} in the list.
            listView.setAdapter(adapter);

            // Set a click listener to play the audio when the list item is clicked on
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                    // Release the media player if it currently exists because we are about to
                    // play a different sound file
                    releaseMediaPlayer();

                    // Get the {@link Word} object at the given position the user clicked on
                    Word word = words.get(position);

                    // Request audio focus so in order to play the audio file. The app needs to play a
                    // short audio file, so we will request audio focus with a short amount of time
                    // with AUDIOFOCUS_GAIN_TRANSIENT.
                    int result = mAudioManager.requestAudioFocus(mOnAudioFocusChangeListener,
                            AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);

                    if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                        // We have audio focus now.

                        // Create and setup the {@link MediaPlayer} for the audio resource associated
                        // with the current word
                        mMediaPlayer = MediaPlayer.create(getActivity(), word.getAudioResourceId());

                        // Start the audio file
                        mMediaPlayer.start();

                        // Setup a listener on the media player, so that we can stop and release the
                        // media player once the sound has finished playing.
                        mMediaPlayer.setOnCompletionListener(mCompletionListener);
                    }
                }
            });


        }
       /* rules = view.findViewById(R.id.rules);

        if(title.equals("Football rules")){
            rules.setText(R.string.footBall);

        }
        if(title.equals("Basketball rules")){
            rules.setText(R.string.basktBall);
        }
        if(title.equals("Tennis rules")){
            rules.setText(R.string.tennis);

        }*/
      /*  listView = view.findViewById(R.id.List);
        wordsList.add("FOOTBALL");       //add titles
        wordsList.add("BASKETBALL");
        wordsList.add("TENNIS");
        wordsList.add("SCHEDULE");
        wordsList.add("PROFILE");
        wordsList.add("MAP");
        wordsList.add("VISUALIZE");
        wordsList.add("HUMAN LIBRARY");
        ArrayAdapter androidListAdapter;
        androidListAdapter = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1 ,wordsList);

        listView.setAdapter(androidListAdapter);
      /*  start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent ;
                if(title.equals("Football rules")){
intent = new Intent(SampleFragment.this, MainActivity.class);
                }
                if(title.equals("Basketball rules")){
                    rules.setText(R.string.basktBall);
                }
                if(title.equals("Tennis rules")){
                    rules.setText(R.string.tennis);

                }
            }
        });*/

        return view;
    }




    public static SampleFragment newInstance(String title) {

        Bundle args = new Bundle();
        args.putString("title", title);
        SampleFragment fragment = new SampleFragment();
        fragment.setArguments(args);
        return fragment;
    }
    /**
     * Clean up the media player by releasing its resources.
     */
    private void releaseMediaPlayer() {
        // If the media player is not null, then it may be currently playing a sound.
        if (mMediaPlayer != null) {
            // Regardless of the current state of the media player, release its resources
            // because we no longer need it.
            mMediaPlayer.release();

            // Set the media player back to null. For our code, we've decided that
            // setting the media player to null is an easy way to tell that the media player
            // is not configured to play an audio file at the moment.
            mMediaPlayer = null;

            // Regardless of whether or not we were granted audio focus, abandon it. This also
            // unregisters the AudioFocusChangeListener so we don't get anymore callbacks.
            mAudioManager.abandonAudioFocus(mOnAudioFocusChangeListener);
        }
    }



}
