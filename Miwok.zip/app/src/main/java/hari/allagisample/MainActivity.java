package hari.allagisample;

import android.content.Intent;
import android.database.DataSetObserver;
import android.media.AudioManager;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import hari.allagi.Allagi;


public class MainActivity extends AppCompatActivity {
    ImageButton start;
     String titel;
    private AudioManager mAudioManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       // start = findViewById(R.id.start);
        ArrayList<String> menuList = new ArrayList<>();     //menu titles
        ArrayList<Integer> imagesList = new ArrayList<>();      //menu backgrounds
        ArrayList<Fragment> fragmentsList = new ArrayList<>();//fragments for each menu headers in second activity


        menuList.add("NUMBERS");       //add titles
        menuList.add("FAMILY");
        menuList.add("COLORS");
        menuList.add("PHRASES");


        imagesList.add(R.drawable.gradient_soccerr);        //add background images
        imagesList.add(R.drawable.gradient_basket);
        imagesList.add(R.drawable.gradient_teness);
        imagesList.add(R.drawable.gradient_try);

        fragmentsList.add(SampleFragment.newInstance("NUMBERS"));      //add fragment instances
        fragmentsList.add(SampleFragment.newInstance("FAMILY"));
        fragmentsList.add(SampleFragment.newInstance("COLORS"));
        fragmentsList.add(SampleFragment.newInstance("PHRASES"));

        Allagi allagi = Allagi.initialize(MainActivity.this, menuList, imagesList, fragmentsList);
        allagi.setTransitionDuration(800);
        allagi.start();

      /*  start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, FootBallActivity.class); ;
                /*if(title.equals("Football rules")){
                    intent =
                }
                if(title.equals("Basketball rules")){
                    rules.setText(R.string.basktBall);
                }
                if(title.equals("Tennis rules")){
                    rules.setText(R.string.tennis);

                }
            }
        });*/
        //start the menu list activity

    }


    @Override
    protected void onStart() {
        super.onStart();
       // Toast.makeText(MainActivity.this,"start",Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        //Toast.makeText(MainActivity.this,"Pause",Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
       // Toast.makeText(MainActivity.this,"Resume",Toast.LENGTH_SHORT).show();
    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
      //  Toast.makeText(MainActivity.this,"Destroy",Toast.LENGTH_SHORT).show();
    }
}
